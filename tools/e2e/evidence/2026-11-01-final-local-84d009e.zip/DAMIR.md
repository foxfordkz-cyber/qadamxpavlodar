# Green Pavlodar — независимая браузерная приёмка

Полные mock и API пройдены на текущем коммите.

Собрано: 2026-10-31T19:14:40.296Z. SHA: c7f15755c80292509aaeeb9f9e4638f62c8b6810. Тип пакета: accepted-local-build.

| Набор | Passed | Failed | Skipped | Fixme | Flaky | Not run | SHA | Состояние |
|---|---:|---:|---:|---:|---:|---:|---|---|
| mock | 292 | 0 | 2 | 0 | 0 | 0 | c7f15755c80292509aaeeb9f9e4638f62c8b6810 | finished |
| api | 78 | 0 | 0 | 0 | 0 | 0 | c7f15755c80292509aaeeb9f9e4638f62c8b6810 | finished |
| smoke | — | — | — | — | — | — | неизвестен | нет отчёта |
| screens | — | — | — | — | — | — | неизвестен | нет отчёта |
| bugs | — | — | — | — | — | — | неизвестен | нет отчёта |

Условия запусков (время UTC):

- mock: runId=edac9af4-ca6c-470e-ad80-e9949e8cf7fc; node scripts/run.mjs mock; http://localhost:5176; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=2, retries=0; 2026-10-31T18:54:28.672Z → 2026-10-31T19:09:13.592Z; exit=0; dirty=false.
- api: runId=5f339aba-5858-4a52-b5d6-f90520c143c9; node scripts/run.mjs api; http://localhost:5177; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=1, retries=0; 2026-10-31T19:10:19.852Z → 2026-10-31T19:13:28.871Z; exit=0; dirty=false.

Причины пропусков:

- mock/desktop: mobile report: document fits the viewport and wide tables scroll internally — The report overflow regression targets 375×812
- mock/desktop: mobile: bottom sheet expands from under 60% to about 90% — Only the 375×812 layout has a bottom sheet

В доступных результатах падений и fixme нет; отсутствие отчёта не означает успешную проверку.

Снимки: 30/30 с совпадающими SHA/runId/хэшами; просмотрено 30. Старые и неподтверждённые PNG не включаются в архив.

История запусков этого SHA (P/F/S/X/Flaky):

| Набор | Run ID | SHA | P/F/S/X/Flaky | Выборка | Начат UTC | Закончен UTC | Exit |
|---|---|---|---|---|---|---|---|---|
| mock | edac9af4-ca6c-470e-ad80-e9949e8cf7fc | c7f15755c80292509aaeeb9f9e4638f62c8b6810 | 292/0/2/0/0 | full | 2026-10-31T18:54:28.672Z | 2026-10-31T19:09:13.592Z | 0 |
| api | 5f339aba-5858-4a52-b5d6-f90520c143c9 | c7f15755c80292509aaeeb9f9e4638f62c8b6810 | 78/0/0/0/0 | full | 2026-10-31T19:10:19.852Z | 2026-10-31T19:13:28.871Z | 0 |

Локальный API не доказывает работу Docker или публичного HTTPS. Проверка DOCX/XML не является открытием файла в Microsoft Word. Эти проверки и ручной сценарий защиты отмечаются отдельно.
