# Green Pavlodar — независимая браузерная приёмка

Полная приёмка mock + API ещё не подтверждена.

Собрано: 2026-10-31T02:03:11.256Z. SHA: 82b2246932b732515b4a306503e9e8a3d9d4dd30. Тип пакета: diagnostic-not-accepted.

| Набор | Passed | Failed | Skipped | Fixme | Flaky | Not run | SHA | Состояние |
|---|---:|---:|---:|---:|---:|---:|---|---|
| mock | 240 | 4 | 2 | 0 | 0 | 0 | 82b2246932b732515b4a306503e9e8a3d9d4dd30 | finished |
| api | 74 | 0 | 0 | 0 | 0 | 0 | 82b2246932b732515b4a306503e9e8a3d9d4dd30 | finished |
| smoke | — | — | — | — | — | — | неизвестен | нет отчёта |
| screens | — | — | — | — | — | — | неизвестен | нет отчёта |
| bugs | — | — | — | — | — | — | неизвестен | нет отчёта |

Условия запусков (время UTC):

- mock: runId=3db2b5eb-7503-4d6e-8419-3b93c6a3a958; node scripts/run.mjs mock; http://localhost:5176; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=2, retries=0; 2026-10-31T01:51:28.855Z → 2026-10-31T02:01:53.513Z; exit=1; dirty=false.
- api: runId=5c058ae9-b698-42be-b8dc-20cda2b18561; node scripts/run.mjs api; http://localhost:5177; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=1, retries=0; 2026-10-31T01:51:47.934Z → 2026-10-31T01:56:57.005Z; exit=0; dirty=false.

Причины пропусков:

- mock/desktop: mobile report: document fits the viewport and wide tables scroll internally — The report overflow regression targets 375×812
- mock/desktop: mobile: bottom sheet expands from under 60% to about 90% — Only the 375×812 layout has a bottom sheet

- mock/desktop → mobile assistant: ru, cost and primary actions stay uncovered at 375px → ожидалось: проверка пройдена → получилось: failed.
- mock/desktop → mobile assistant: kk, cost and primary actions stay uncovered at 375px → ожидалось: проверка пройдена → получилось: failed.
- mock/mobile → mobile assistant: ru, cost and primary actions stay uncovered at 375px → ожидалось: проверка пройдена → получилось: failed.
- mock/mobile → mobile assistant: kk, cost and primary actions stay uncovered at 375px → ожидалось: проверка пройдена → получилось: failed.

Снимки: 30/30 с совпадающими SHA/runId/хэшами; просмотрено 0. Старые и неподтверждённые PNG не включаются в архив.

История запусков этого SHA (P/F/S/X/Flaky):

| Набор | Run ID | SHA | P/F/S/X/Flaky | Выборка | Начат UTC | Закончен UTC | Exit |
|---|---|---|---|---|---|---|---|---|
| mock | 3db2b5eb-7503-4d6e-8419-3b93c6a3a958 | 82b2246932b732515b4a306503e9e8a3d9d4dd30 | 240/4/2/0/0 | full | 2026-10-31T01:51:28.855Z | 2026-10-31T02:01:53.513Z | 1 |
| api | 5c058ae9-b698-42be-b8dc-20cda2b18561 | 82b2246932b732515b4a306503e9e8a3d9d4dd30 | 74/0/0/0/0 | full | 2026-10-31T01:51:47.934Z | 2026-10-31T01:56:57.005Z | 0 |

Локальный API не доказывает работу Docker или публичного HTTPS. Проверка DOCX/XML не является открытием файла в Microsoft Word. Эти проверки и ручной сценарий защиты отмечаются отдельно.
