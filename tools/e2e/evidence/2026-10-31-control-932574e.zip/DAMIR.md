# Green Pavlodar — независимая браузерная приёмка

Контрольная 932574e: mock 283/1/2, API 74/0. Не финальная приёмка; E2E-11 проверяется отдельно, исправление KK ожидается..

Собрано: 2026-10-31T18:09:54.229Z. SHA: cdc3ec257726ef937b0bbf953253a755f2e225a9. Тип пакета: diagnostic-not-accepted.

| Набор | Passed | Failed | Skipped | Fixme | Flaky | Not run | SHA | Состояние |
|---|---:|---:|---:|---:|---:|---:|---|---|
| mock | 283 | 1 | 2 | 0 | 0 | 0 | cdc3ec257726ef937b0bbf953253a755f2e225a9 | finished |
| api | 74 | 0 | 0 | 0 | 0 | 0 | cdc3ec257726ef937b0bbf953253a755f2e225a9 | finished |
| smoke | — | — | — | — | — | — | неизвестен | нет отчёта |
| screens | — | — | — | — | — | — | неизвестен | нет отчёта |
| bugs | — | — | — | — | — | — | неизвестен | нет отчёта |

Условия запусков (время UTC):

- mock: runId=316395a6-3c9e-4b36-84d7-2d6a0652bf5f; node scripts/run.mjs mock; http://localhost:5176; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=2, retries=0; 2026-10-31T17:39:26.501Z → 2026-10-31T17:53:34.909Z; exit=1; dirty=false.
- api: runId=98c7f1fa-6623-48ae-9c59-090713e4811d; node scripts/run.mjs api; http://localhost:5177; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=1, retries=0; 2026-10-31T17:53:47.716Z → 2026-10-31T17:57:24.429Z; exit=0; dirty=false.

Причины пропусков:

- mock/desktop: mobile report: document fits the viewport and wide tables scroll internally — The report overflow regression targets 375×812
- mock/desktop: mobile: bottom sheet expands from under 60% to about 90% — Only the 375×812 layout has a bottom sheet

- mock/desktop → drawing kk: search counters, undo, save a polygon and reopen after reload → ожидалось: проверка пройдена → получилось: failed.

Снимки: 30/30 с совпадающими SHA/runId/хэшами; просмотрено 30. Старые и неподтверждённые PNG не включаются в архив.

История запусков этого SHA (P/F/S/X/Flaky):

| Набор | Run ID | SHA | P/F/S/X/Flaky | Выборка | Начат UTC | Закончен UTC | Exit |
|---|---|---|---|---|---|---|---|---|
| mock | 316395a6-3c9e-4b36-84d7-2d6a0652bf5f | cdc3ec257726ef937b0bbf953253a755f2e225a9 | 283/1/2/0/0 | full | 2026-10-31T17:39:26.501Z | 2026-10-31T17:53:34.909Z | 1 |
| api | 98c7f1fa-6623-48ae-9c59-090713e4811d | cdc3ec257726ef937b0bbf953253a755f2e225a9 | 74/0/0/0/0 | full | 2026-10-31T17:53:47.716Z | 2026-10-31T17:57:24.429Z | 0 |

Локальный API не доказывает работу Docker или публичного HTTPS. Проверка DOCX/XML не является открытием файла в Microsoft Word. Эти проверки и ручной сценарий защиты отмечаются отдельно.
