# Green Pavlodar — независимая браузерная приёмка

Полные mock и API пройдены на текущем коммите.

Собрано: 2026-10-31T10:23:34.809Z. SHA: b836605ed1ecb5eea3425f52bf2f47b178487de5. Тип пакета: accepted-local-build.

| Набор | Passed | Failed | Skipped | Fixme | Flaky | Not run | SHA | Состояние |
|---|---:|---:|---:|---:|---:|---:|---|---|
| mock | 272 | 0 | 2 | 0 | 0 | 0 | b836605ed1ecb5eea3425f52bf2f47b178487de5 | finished |
| api | 74 | 0 | 0 | 0 | 0 | 0 | b836605ed1ecb5eea3425f52bf2f47b178487de5 | finished |
| smoke | — | — | — | — | — | — | неизвестен | нет отчёта |
| screens | — | — | — | — | — | — | неизвестен | нет отчёта |
| bugs | — | — | — | — | — | — | неизвестен | нет отчёта |

Условия запусков (время UTC):

- mock: runId=3355197d-c2c4-4765-adb3-1f6215310cc3; node scripts/run.mjs mock; http://localhost:5176; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=2, retries=0; 2026-10-31T10:02:13.439Z → 2026-10-31T10:22:12.768Z; exit=0; dirty=false.
- api: runId=cfdbf82c-a83f-4324-ab5e-9a2d0719ef42; node scripts/run.mjs api; http://localhost:5177; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=1, retries=0; 2026-10-31T10:02:46.202Z → 2026-10-31T10:12:34.231Z; exit=0; dirty=false.

Причины пропусков:

- mock/desktop: mobile report: document fits the viewport and wide tables scroll internally — The report overflow regression targets 375×812
- mock/desktop: mobile: bottom sheet expands from under 60% to about 90% — Only the 375×812 layout has a bottom sheet

В доступных результатах падений и fixme нет; отсутствие отчёта не означает успешную проверку.

Снимки: 30/30 с совпадающими SHA/runId/хэшами; просмотрено 30. Старые и неподтверждённые PNG не включаются в архив.

История запусков этого SHA (P/F/S/X/Flaky):

| Набор | Run ID | SHA | P/F/S/X/Flaky | Выборка | Начат UTC | Закончен UTC | Exit |
|---|---|---|---|---|---|---|---|---|
| mock | 3355197d-c2c4-4765-adb3-1f6215310cc3 | b836605ed1ecb5eea3425f52bf2f47b178487de5 | 272/0/2/0/0 | full | 2026-10-31T10:02:13.439Z | 2026-10-31T10:22:12.768Z | 0 |
| api | cfdbf82c-a83f-4324-ab5e-9a2d0719ef42 | b836605ed1ecb5eea3425f52bf2f47b178487de5 | 74/0/0/0/0 | full | 2026-10-31T10:02:46.202Z | 2026-10-31T10:12:34.231Z | 0 |

Локальный API не доказывает работу Docker или публичного HTTPS. Проверка DOCX/XML не является открытием файла в Microsoft Word. Эти проверки и ручной сценарий защиты отмечаются отдельно.
