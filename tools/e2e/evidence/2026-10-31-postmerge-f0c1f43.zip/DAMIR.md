# Green Pavlodar — независимая браузерная приёмка

Полные mock и API пройдены на текущем коммите.

Собрано: 2026-10-31T17:04:59.508Z. SHA: f0c1f43eb424408ef0db7fad6e263bb17e34f995. Тип пакета: accepted-local-build.

| Набор | Passed | Failed | Skipped | Fixme | Flaky | Not run | SHA | Состояние |
|---|---:|---:|---:|---:|---:|---:|---|---|
| mock | 276 | 0 | 2 | 0 | 0 | 0 | f0c1f43eb424408ef0db7fad6e263bb17e34f995 | finished |
| api | 74 | 0 | 0 | 0 | 0 | 0 | f0c1f43eb424408ef0db7fad6e263bb17e34f995 | finished |
| smoke | — | — | — | — | — | — | неизвестен | нет отчёта |
| screens | — | — | — | — | — | — | неизвестен | нет отчёта |
| bugs | — | — | — | — | — | — | неизвестен | нет отчёта |

Условия запусков (время UTC):

- mock: runId=7a204c44-ee17-4a09-99db-02b8223d5ed1; node scripts/run.mjs mock; http://localhost:5176; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=2, retries=0; 2026-10-31T16:47:37.897Z → 2026-10-31T17:01:49.255Z; exit=0; dirty=false.
- api: runId=4051f137-404f-4183-afb4-e6b0065d43fe; node scripts/run.mjs api; http://localhost:5177; Node 24.22.2, Playwright 1.64.1, win32/x64, workers=1, retries=0; 2026-10-31T16:27:12.093Z → 2026-10-31T16:37:42.046Z; exit=0; dirty=false.

Причины пропусков:

- mock/desktop: mobile report: document fits the viewport and wide tables scroll internally — The report overflow regression targets 375×812
- mock/desktop: mobile: bottom sheet expands from under 60% to about 90% — Only the 375×812 layout has a bottom sheet

В доступных результатах падений и fixme нет; отсутствие отчёта не означает успешную проверку.

Снимки: 30/30 с совпадающими SHA/runId/хэшами; просмотрено 30. Старые и неподтверждённые PNG не включаются в архив.

История запусков этого SHA (P/F/S/X/Flaky):

| Набор | Run ID | SHA | P/F/S/X/Flaky | Выборка | Начат UTC | Закончен UTC | Exit |
|---|---|---|---|---|---|---|---|---|
| mock | 4fe73fc8-dfd4-4e8d-aa24-a89fc0e641d8 | f0c1f43eb424408ef0db7fad6e263bb17e34f995 | 275/1/2/0/0 | full | 2026-10-31T16:26:25.594Z | 2026-10-31T16:47:02.636Z | 1 |
| api | 4051f137-404f-4183-afb4-e6b0065d43fe | f0c1f43eb424408ef0db7fad6e263bb17e34f995 | 74/0/0/0/0 | full | 2026-10-31T16:27:12.093Z | 2026-10-31T16:37:42.046Z | 0 |
| mock | 7a204c44-ee17-4a09-99db-02b8223d5ed1 | f0c1f43eb424408ef0db7fad6e263bb17e34f995 | 276/0/2/0/0 | full | 2026-10-31T16:47:37.897Z | 2026-10-31T17:01:49.255Z | 0 |

Локальный API не доказывает работу Docker или публичного HTTPS. Проверка DOCX/XML не является открытием файла в Microsoft Word. Эти проверки и ручной сценарий защиты отмечаются отдельно.
