Public mock evidence for Green Pavlodar, 2026-10-31

Application source: fdc6e756be99dc5ba3a7a48ca1df17c4bfbef5ef
Cloudflare deployment: f816c350-5722-4b56-a180-4124da01c5ba
Original QA code: 3995322943d1973942698e6fe4287b82423ded18
Result: Original suite 16 passed, 0 failed/skipped/flaky; separate E2E10 4/4.
All 24 PNGs visually reviewed. Tests ran from clean main fdc6e75; tools/e2e
tree exactly matches original QA3995322, with no tool edits.

This is the Tanirberdi Codex team's repeat of the unchanged QA40 public
mock suite, not a new independent acceptance by Aidana and not API acceptance.

Contents: unchanged portable summary and run manifest, 20 original passing
PNG attachments, four onboarding PNGs and their safe result JSON,
and four original E2E09 hit-test JSON attachments.
All paths under screenshots/ and hit-tests/ are relative to this ZIP root.

The metadata records hashes of local raw reports and an external HTTP proof.
Those are references, not ZIP contents: raw-results.json, results.json,
public-suite.log and deployment-byte-verification.json are intentionally
excluded. Raw reports remain local and may contain machine-specific paths.
The deployment proof is published separately in the repository:
docs/cloudflare-evidence/2026-10-31-published-fdc6e75.json

The old hardcoded publisherReportedSHA in the original runner was not edited.
The summary/run-manifest explain current source and deployment provenance.
No authentication material, environment files, test runner, error contexts
or local machine paths are included in this evidence archive.
