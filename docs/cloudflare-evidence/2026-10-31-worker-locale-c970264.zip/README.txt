Worker locale QA: c970264

12 embedded cases passed on exact API candidate preview port 5199; 2 standalone cases passed on source preview 5198.
38 screenshots manually reviewed. Local mock/synthetic HTTP only, not public cloud acceptance.
The app badge Server /api/v1 in HTTP screenshots identifies the adapter; its responses were supplied by an isolated browser interceptor for this test.
Source data names and notes are not automatically translated.
See summary.json for scope, exact archive identity, state retention, retry evidence and harness diagnostic limitations.
No raw authentication data, operation identifiers, harness scripts or personal paths included.
