Public mock evidence for Green Pavlodar, 2026-10-31

Application source: 98cf6c68d5370331d6f95aa9e749f82d504e5670
Cloudflare deployment: 1079de0b-d78a-4350-8242-e718d2aad30e
Original QA code: 3995322943d1973942698e6fe4287b82423ded18
Result: 16 passed, 0 failed/skipped/flaky. All 20 PNGs visually reviewed.

This is the Tanirberdi Codex team's repeat of the unchanged QA40 public
mock suite, not a new independent acceptance by Aidana and not API acceptance.

Contents: unchanged portable summary and run manifest, 20 original passing
PNG attachments, and four original E2E09 hit-test JSON attachments.
All paths under screenshots/ and hit-tests/ are relative to this ZIP root.

The metadata records hashes of local raw reports and an external HTTP proof.
Those are references, not ZIP contents: raw-results.json, results.json,
public-suite.log and deployment-byte-verification.json are intentionally
excluded. Raw reports remain local and may contain machine-specific paths.
The deployment proof is published separately in the repository:
docs/cloudflare-evidence/2026-10-31-published-98cf6c6.json

The old hardcoded publisherReportedSHA in the original runner was not edited.
The summary/run-manifest explain current source and deployment provenance.
No authentication material, environment files, test runner, error contexts
or local machine paths are included in this evidence archive.
